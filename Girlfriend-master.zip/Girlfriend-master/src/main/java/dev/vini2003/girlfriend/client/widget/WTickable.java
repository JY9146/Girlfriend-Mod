package dev.vini2003.girlfriend.client.widget;

public interface WTickable {
	void setTicks(long ticks);
	
	long getTicks();
}
