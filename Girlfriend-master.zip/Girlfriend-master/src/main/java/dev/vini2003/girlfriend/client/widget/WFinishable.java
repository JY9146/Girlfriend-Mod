package dev.vini2003.girlfriend.client.widget;

public interface WFinishable {
	boolean isFinished();
}
