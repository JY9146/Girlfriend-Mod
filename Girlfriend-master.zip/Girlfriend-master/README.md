# Girlfriend

This mod adds a girlfriend to Minecraft.

# Installing

- Install Fabric from [their website](http://fabricmc.net/).

- Place the mod under `%AppData%`, `.minecraft/mods`.
